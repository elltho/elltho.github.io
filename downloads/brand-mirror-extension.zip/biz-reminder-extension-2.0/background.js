// background.js (MV3 service worker)

// Show notification 15 seconds after a page finishes loading
const DELAY_MS = 15000; // 15 seconds
const KEY_PREFIX = "bm:"; // alarm name prefix

// In-memory schedule cache (resets when SW sleeps, alarms still wake it)
const scheduled = new Map(); // tabId -> { url, alarmName, when }

function log(...args) {
  console.log("[BrandMirror BG]", ...args);
}

function alarmNameFor(tabId) {
  return `${KEY_PREFIX}${tabId}`;
}

function isHttpUrl(url) {
  return /^https?:\/\//i.test(url || "");
}

async function scheduleForTab(tabId, url) {
  if (!tabId || !isHttpUrl(url)) return;

  const existing = scheduled.get(tabId);
  const now = Date.now();
  const when = now + DELAY_MS;
  const name = alarmNameFor(tabId);

  // If we already scheduled for THIS exact URL and it's still in the future, don't reset it.
  if (existing && existing.url === url && existing.when > now) {
    log("Already scheduled (keeping):", name, "for", url);
    return;
  }

  // Clear any prior alarm for this tab
  await chrome.alarms.clear(name);

  // Schedule a one-shot alarm at an absolute time
  chrome.alarms.create(name, { when });
  scheduled.set(tabId, { url, alarmName: name, when });

  log("Scheduled alarm:", name, "in", Math.round((when - now) / 1000), "s for", url);
}

chrome.runtime.onInstalled.addListener(() => {
  log("onInstalled fired");
});

// When a tab finishes loading, schedule notification in 15s
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  if (!tab?.url) return;
  if (!isHttpUrl(tab.url)) return;

  log("Tab complete:", tabId, tab.url);
  scheduleForTab(tabId, tab.url);
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm?.name?.startsWith(KEY_PREFIX)) return;

  // Parse tabId
  const tabIdStr = alarm.name.slice(KEY_PREFIX.length);
  const tabId = Number(tabIdStr);
  if (!Number.isFinite(tabId)) return;

  // Check tab still exists and URL still matches what we scheduled for
  let tab;
  try {
    tab = await chrome.tabs.get(tabId);
  } catch {
    log("Tab gone, skipping notification:", tabId);
    scheduled.delete(tabId);
    return;
  }

  const entry = scheduled.get(tabId);
  if (entry && tab.url !== entry.url) {
    log("URL changed since scheduling. Skipping notification.", "Was:", entry.url, "Now:", tab.url);
    return;
  }

  // Fire notification
  // Embed tabId in the notificationId so we don't need storage.session
  const notifId = `bm-notif:${tabId}:${Date.now()}`;

  await chrome.notifications.create(notifId, {
    type: "basic",
    iconUrl: chrome.runtime.getURL("icon.png"),
    title: "Brand Mirror",
    message: "Want a 10-second homepage read?",
    priority: 2
  });

  log("Notification created:", notifId);

  // cleanup so we can schedule again later
  scheduled.delete(tabId);
});

// OPTION 2: Clicking notification focuses the original tab/window (NO new window/tab)
chrome.notifications.onClicked.addListener(async (notificationId) => {
  try {
    // notificationId format: bm-notif:<tabId>:<timestamp>
    const parts = String(notificationId || "").split(":");
    const tabId = Number(parts[1]);

    if (!Number.isFinite(tabId) || tabId <= 0) {
      log("Could not parse tabId from notificationId:", notificationId);
      return;
    }

    const tab = await chrome.tabs.get(tabId);

    if (tab?.windowId != null) {
      await chrome.windows.update(tab.windowId, { focused: true });
    }
    await chrome.tabs.update(tabId, { active: true });

    log("Focused tab from notification click:", tabId);
  } catch (e) {
    console.warn("[BrandMirror BG] Notification click focus failed:", e);
  }
});