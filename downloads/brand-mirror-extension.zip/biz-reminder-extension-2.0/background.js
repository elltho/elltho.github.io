// background.js (MV3 service worker)

const DELAY_MS = 15000; // 15 seconds
const KEY_PREFIX = "bm:"; // alarm name prefix

// Keep a tiny in-memory cache (resets when SW sleeps, but alarms will wake it)
const scheduled = new Map(); // tabId -> { url, alarmName, when }

function log(...args) {
  console.log("[BrandMirror BG]", ...args);
}

function alarmNameFor(tabId) {
  return `${KEY_PREFIX}${tabId}`;
}

async function scheduleForTab(tabId, url) {
  if (!tabId || !url) return;

  // Avoid scheduling for chrome:// pages etc
  if (!/^https?:\/\//i.test(url)) return;

  const existing = scheduled.get(tabId);
  const now = Date.now();
  const when = now + DELAY_MS;
  const name = alarmNameFor(tabId);

  // If we already scheduled for THIS exact URL and it's still in the future, don't reset it.
  if (existing && existing.url === url && existing.when > now) {
    log("Already scheduled (keeping):", name, "for", url);
    return;
  }

  // Clear any prior alarm for this tab
  await chrome.alarms.clear(name);
  log("Cleared alarm:", name);

  // Schedule a one-shot alarm at an absolute time
  chrome.alarms.create(name, { when });
  scheduled.set(tabId, { url, alarmName: name, when });

  log("Scheduled alarm:", name, "in", Math.round((when - now) / 1000), "s for", url);
}

chrome.runtime.onInstalled.addListener(() => {
  log("onInstalled fired");
});

// When a tab finishes loading, schedule notification in 15s
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  if (!tab?.url) return;

  log("Tab complete:", tabId, tab.url);
  scheduleForTab(tabId, tab.url);
});

// If user switches tabs, also schedule (optional)
// chrome.tabs.onActivated.addListener(async ({ tabId }) => {
//   const tab = await chrome.tabs.get(tabId);
//   if (tab?.url) scheduleForTab(tabId, tab.url);
// });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm?.name?.startsWith(KEY_PREFIX)) return;

  log("onAlarm fired:", alarm.name);

  // Parse tabId
  const tabIdStr = alarm.name.replace(KEY_PREFIX, "");
  const tabId = Number(tabIdStr);
  if (!Number.isFinite(tabId)) return;

  // Check tab still exists and URL still matches what we scheduled for
  let tab;
  try {
    tab = await chrome.tabs.get(tabId);
  } catch (e) {
    log("Tab gone, skipping notification:", tabId);
    scheduled.delete(tabId);
    return;
  }

  const entry = scheduled.get(tabId);
  if (!entry) {
    log("No schedule entry found (SW may have restarted). Showing generic notification anyway.");
  } else if (tab.url !== entry.url) {
    log("URL changed since scheduling. Skipping notification.", "Was:", entry.url, "Now:", tab.url);
    return;
  }

  // Fire notification
  const notifId = `bm-notif:${tabId}:${Date.now()}`;
  await chrome.notifications.create(notifId, {
    type: "basic",
    iconUrl: chrome.runtime.getURL("icon.png"),
    title: "Brand Mirror",
    message: "Want a 10-second homepage read?",
    priority: 2,
  });

  log("Notification created:", notifId);

  // cleanup so we can schedule again later
  scheduled.delete(tabId);
});

// Optional: clicking notification opens the popup page in a tab (safe & reliable)
chrome.notifications.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL("popup.html");
  await chrome.tabs.create({ url });
});