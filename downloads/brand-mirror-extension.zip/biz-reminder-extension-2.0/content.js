// content.js — Brand Mirror signals collector (above-the-fold + popups)

function inViewport(rect, vh) {
  return rect.bottom > 0 && rect.top < vh && rect.width > 4 && rect.height > 4;
}

function visible(el) {
  const s = window.getComputedStyle(el);
  if (!s) return true;
  if (s.display === "none" || s.visibility === "hidden") return false;
  if (parseFloat(s.opacity || "1") === 0) return false;
  return true;
}

function aboveFoldEls(selector) {
  const vh = window.innerHeight || 800;
  return Array.from(document.querySelectorAll(selector)).filter((el) => {
    if (!visible(el)) return false;
    const r = el.getBoundingClientRect();
    return inViewport(r, vh);
  });
}

function uniq(arr) {
  const out = [];
  const seen = new Set();
  for (const x of arr) {
    const k = (x || "").trim().toLowerCase();
    if (!k) continue;
    if (seen.has(k)) continue;
    seen.add(k);
    out.push((x || "").trim());
  }
  return out;
}

function getTextSnippets() {
  const els = aboveFoldEls("h1,h2,p,li,small,strong,em,button,a,span");
  const out = [];
  for (const el of els) {
    const t = (el.innerText || "").trim().replace(/\s+/g, " ");
    if (!t) continue;
    if (t.length > 220) continue;
    out.push(t);
  }
  return uniq(out).slice(0, 70);
}

function getHeadline() {
  const h1 = aboveFoldEls("h1")[0];
  if (h1) return (h1.innerText || "").trim();
  const h2 = aboveFoldEls("h2")[0];
  if (h2) return (h2.innerText || "").trim();
  // fallback: biggest text-ish element
  const candidates = aboveFoldEls("div,section,header,p,span").slice(0, 50);
  let best = "";
  let bestSize = 0;
  for (const el of candidates) {
    const t = (el.innerText || "").trim();
    if (!t || t.length < 8 || t.length > 120) continue;
    const fs = parseFloat(getComputedStyle(el).fontSize || "0");
    if (fs > bestSize) {
      bestSize = fs;
      best = t.replace(/\s+/g, " ");
    }
  }
  return best;
}

function getCTAs() {
  // For ecommerce, lots of clickables aren't CTAs. We use "bigger + labeled" heuristic.
  const els = aboveFoldEls("button, a, [role='button'], input[type='submit']");
  const labels = [];

  for (const el of els) {
    const r = el.getBoundingClientRect();
    const label = (el.innerText || el.value || "").trim().replace(/\s+/g, " ");
    if (!label) continue;

    // ignore tiny / icon buttons
    if (r.width < 90 || r.height < 32) continue;

    // ignore extremely long labels (menus)
    if (label.length > 45) continue;

    // ignore one-char
    if (label.length <= 1) continue;

    labels.push(label);
  }

  return uniq(labels).slice(0, 10);
}

function detectOffer(snips) {
  const t = snips.join(" ").toLowerCase();
  return (
    /(\b\d{1,3}\s*%)/.test(t) ||
    /\boff\b/.test(t) ||
    /\bdiscount\b/.test(t) ||
    /\bsale\b/.test(t) ||
    /\brabatt\b/.test(t) ||
    /\brea\b/.test(t) ||
    /\berbjudande\b/.test(t) ||
    /\bkampanj\b/.test(t)
  );
}

function detectTrustSnippets(snips) {
  const patterns = [
    /trustpilot|reviews?|rating|stars?/i,
    /recension(er)?|omdömen|betyg/i,
    /loved by|trusted by|customers|users/i,
    /älskad av|betrodd av|kunder|användare/i,
    /\b\d{1,3}([.,\s]\d{3})+\s*\+?/i, // 200 000+
    /\b\d+\s*(k|m)\s*\+/i // 50k+, 2m+
  ];
  return snips.filter((s) => patterns.some((r) => r.test(s))).slice(0, 6);
}

function guessLanguage(snips) {
  const t = snips.join(" ").toLowerCase();
  const svWords = ["och", "att", "för", "med", "våra", "kontakta", "produkter", "fri frakt", "kund"];
  const hits = svWords.filter((w) => t.includes(` ${w} `) || t.startsWith(`${w} `)).length;
  return hits >= 2 ? "sv" : "en";
}

function wordCount(snips) {
  return snips.join(" ").split(/\s+/).filter(Boolean).length;
}

function detectPopups() {
  // Try to detect modals/overlays above the fold:
  // fixed/sticky + high z-index + reasonable size + non-trivial text
  const vh = window.innerHeight || 800;

  const candidates = Array.from(document.querySelectorAll("div,section,aside,dialog"))
    .filter((el) => {
      if (!visible(el)) return false;
      const r = el.getBoundingClientRect();
      if (!inViewport(r, vh)) return false;

      const s = getComputedStyle(el);
      const pos = s.position;
      if (pos !== "fixed" && pos !== "sticky") return false;

      const z = parseInt(s.zIndex || "0", 10);
      if (!Number.isFinite(z) || z < 100) return false;

      // Not tiny, not full-page background
      if (r.width < 240 || r.height < 120) return false;

      const text = (el.innerText || "").trim();
      if (text.length < 25) return false;

      return true;
    });

  const types = [];
  const joined = candidates.map((x) => (x.innerText || "").toLowerCase()).join(" ");

  if (/(subscribe|newsletter|join|sign up|nyhetsbrev|få \d+%|registrera)/.test(joined)) types.push("newsletter");
  if (/(discount|% off|rabatt|rea|offer|deal|kampanj)/.test(joined)) types.push("discount");
  if (/(cookies|gdpr|consent|integritet|cookie)/.test(joined)) types.push("cookie/consent");

  // Provide a few text snippets as evidence
  const popupSnips = uniq(candidates.map((c) => (c.innerText || "").trim().replace(/\s+/g, " "))).slice(0, 3);

  return {
    popupDetected: candidates.length > 0,
    popupTypes: types.slice(0, 3),
    popupSnippets: popupSnips
  };
}

function collectSignals() {
  const snips = getTextSnippets();
  const head = getHeadline();
  const ctas = getCTAs();
  const trust = detectTrustSnippets(snips);
  const offer = detectOffer(snips);
  const langGuess = guessLanguage(snips);

  const clickables = aboveFoldEls("button, a, [role='button'], input[type='submit']").length;
  const popup = detectPopups();

  return {
    url: location.href,
    langGuess,
    headline: head,
    primaryCtas: ctas,
    offerDetected: offer,
    trustSnippets: trust,
    popupDetected: popup.popupDetected,
    popupTypes: popup.popupTypes,
    popupSnippets: popup.popupSnippets,
    words: wordCount(snips),
    clickables,
    snippets: snips.slice(0, 35) // keep payload small
  };
}
// --- Brand Mirror toast (top-right) -----------------------

const BM_TOAST_ID = "bm-toast";
const BM_STYLE_ID = "bm-toast-style";

function ensureToastStyles() {
  if (document.getElementById(BM_STYLE_ID)) return;

  const style = document.createElement("style");
  style.id = BM_STYLE_ID;
  style.textContent = `
    #${BM_TOAST_ID} {
      position: fixed;
      top: 16px;
      right: 16px;
      width: 340px;
      max-width: calc(100vw - 32px);
      z-index: 2147483647;
      transform: translateX(120%);
      transition: transform 240ms ease, opacity 240ms ease;
      opacity: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      pointer-events: none;
    }
    #${BM_TOAST_ID}.show {
      transform: translateX(0);
      opacity: 1;
      pointer-events: auto;
    }
    #${BM_TOAST_ID} .bm-card {
      background: rgba(18, 18, 20, 0.92);
      color: #fff;
      border: 1px solid rgba(255,255,255,0.10);
      border-radius: 16px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      overflow: hidden;
    }
    #${BM_TOAST_ID} .bm-body {
      padding: 14px 14px 12px 14px;
      display: grid;
      grid-template-columns: 28px 1fr auto;
      gap: 10px;
      align-items: start;
    }
    #${BM_TOAST_ID} .bm-icon {
      width: 28px; height: 28px;
      border-radius: 8px;
      background: linear-gradient(135deg, #ff3b5c, #7c4dff);
      display: grid; place-items: center;
      font-weight: 800;
      font-size: 14px;
      user-select: none;
    }
    #${BM_TOAST_ID} .bm-title {
      font-size: 13px;
      font-weight: 700;
      line-height: 1.2;
      margin: 1px 0 2px 0;
    }
    #${BM_TOAST_ID} .bm-sub {
      font-size: 12px;
      line-height: 1.35;
      opacity: 0.85;
      margin: 0;
    }
    #${BM_TOAST_ID} .bm-actions {
      display: flex;
      gap: 8px;
      align-items: center;
    }
    #${BM_TOAST_ID} .bm-btn {
      border: 0;
      background: rgba(255,255,255,0.10);
      color: #fff;
      font-size: 12px;
      padding: 8px 10px;
      border-radius: 10px;
      cursor: pointer;
      transition: transform 120ms ease, background 120ms ease;
    }
    #${BM_TOAST_ID} .bm-btn:hover {
      background: rgba(255,255,255,0.16);
      transform: translateY(-1px);
    }
    #${BM_TOAST_ID} .bm-x {
      width: 32px;
      padding: 8px 0;
      text-align: center;
    }
    #${BM_TOAST_ID} .bm-progress {
      height: 3px;
      background: rgba(255,255,255,0.10);
      position: relative;
      overflow: hidden;
    }
    #${BM_TOAST_ID} .bm-bar {
      position: absolute;
      left: 0; top: 0; bottom: 0;
      width: 0%;
      background: rgba(255,255,255,0.55);
      transition: width linear;
    }
  `;
  document.head.appendChild(style);
}

function removeToast() {
  const el = document.getElementById(BM_TOAST_ID);
  if (!el) return;
  el.classList.remove("show");
  // låt animationen gå klart
  setTimeout(() => el.remove(), 260);
}

function showToast({
  title = "Brand Mirror",
  message = "Want a 10-second homepage read?",
  primaryLabel = "Scan",
  onPrimary,
  durationMs = 8000,
  showProgress = true,
  iconText = "BM"
} = {}) {
  ensureToastStyles();

  // ersätt befintlig toast om den finns
  removeToast();

  const root = document.createElement("div");
  root.id = BM_TOAST_ID;

  root.innerHTML = `
    <div class="bm-card" role="status" aria-live="polite">
      <div class="bm-body">
        <div class="bm-icon">${escapeHtml(iconText)}</div>
        <div>
          <div class="bm-title">${escapeHtml(title)}</div>
          <p class="bm-sub">${escapeHtml(message)}</p>
        </div>
        <div class="bm-actions">
          <button class="bm-btn bm-primary">${escapeHtml(primaryLabel)}</button>
          <button class="bm-btn bm-x" aria-label="Close">✕</button>
        </div>
      </div>
      ${showProgress ? `<div class="bm-progress"><div class="bm-bar"></div></div>` : ""}
    </div>
  `;

  document.documentElement.appendChild(root);

  const primaryBtn = root.querySelector(".bm-primary");
  const closeBtn = root.querySelector(".bm-x");
  const bar = root.querySelector(".bm-bar");

  let timer = null;
  let startedAt = Date.now();
  let remaining = durationMs;

  const start = () => {
    if (timer) clearTimeout(timer);
    startedAt = Date.now();

    if (bar) {
      // reset -> start transition
      bar.style.transitionDuration = "0ms";
      bar.style.width = "0%";
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          bar.style.transitionDuration = `${remaining}ms`;
          bar.style.width = "100%";
        });
      });
    }

    timer = setTimeout(removeToast, remaining);
  };

  const pause = () => {
    if (!timer) return;
    clearTimeout(timer);
    timer = null;
    const elapsed = Date.now() - startedAt;
    remaining = Math.max(0, remaining - elapsed);

    if (bar) {
      // frys bredden
      const computed = getComputedStyle(bar);
      const w = computed.width;
      bar.style.transitionDuration = "0ms";
      bar.style.width = w;
    }
  };

  // interaktioner
  primaryBtn?.addEventListener("click", () => {
    try { onPrimary?.(); } finally { removeToast(); }
  });
  closeBtn?.addEventListener("click", removeToast);

  // hover paus (premium-känsla)
  root.addEventListener("mouseenter", pause);
  root.addEventListener("mouseleave", start);

  // visa (efter att den finns i DOM)
  requestAnimationFrame(() => root.classList.add("show"));

  if (durationMs > 0) start();
}

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "BRAND_MIRROR_SIGNALS") {
    try {
      sendResponse({ ok: true, signals: collectSignals() });
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
  }
  return true;
});