// content.js — Brand Mirror signals collector (above-the-fold + popups)

function inViewport(rect, vh) {
  return rect.bottom > 0 && rect.top < vh && rect.width > 4 && rect.height > 4;
}

function visible(el) {
  const s = window.getComputedStyle(el);
  if (!s) return true;
  if (s.display === "none" || s.visibility === "hidden") return false;
  if (parseFloat(s.opacity || "1") === 0) return false;
  return true;
}

function aboveFoldEls(selector) {
  const vh = window.innerHeight || 800;
  return Array.from(document.querySelectorAll(selector)).filter((el) => {
    if (!visible(el)) return false;
    const r = el.getBoundingClientRect();
    return inViewport(r, vh);
  });
}

function uniq(arr) {
  const out = [];
  const seen = new Set();
  for (const x of arr) {
    const k = (x || "").trim().toLowerCase();
    if (!k) continue;
    if (seen.has(k)) continue;
    seen.add(k);
    out.push((x || "").trim());
  }
  return out;
}

function getTextSnippets() {
  const els = aboveFoldEls("h1,h2,p,li,small,strong,em,button,a,span");
  const out = [];
  for (const el of els) {
    const t = (el.innerText || "").trim().replace(/\s+/g, " ");
    if (!t) continue;
    if (t.length > 220) continue;
    out.push(t);
  }
  return uniq(out).slice(0, 70);
}

function getHeadline() {
  const h1 = aboveFoldEls("h1")[0];
  if (h1) return (h1.innerText || "").trim();
  const h2 = aboveFoldEls("h2")[0];
  if (h2) return (h2.innerText || "").trim();
  // fallback: biggest text-ish element
  const candidates = aboveFoldEls("div,section,header,p,span").slice(0, 50);
  let best = "";
  let bestSize = 0;
  for (const el of candidates) {
    const t = (el.innerText || "").trim();
    if (!t || t.length < 8 || t.length > 120) continue;
    const fs = parseFloat(getComputedStyle(el).fontSize || "0");
    if (fs > bestSize) {
      bestSize = fs;
      best = t.replace(/\s+/g, " ");
    }
  }
  return best;
}

function getCTAs() {
  // For ecommerce, lots of clickables aren't CTAs. We use "bigger + labeled" heuristic.
  const els = aboveFoldEls("button, a, [role='button'], input[type='submit']");
  const labels = [];

  for (const el of els) {
    const r = el.getBoundingClientRect();
    const label = (el.innerText || el.value || "").trim().replace(/\s+/g, " ");
    if (!label) continue;

    // ignore tiny / icon buttons
    if (r.width < 90 || r.height < 32) continue;

    // ignore extremely long labels (menus)
    if (label.length > 45) continue;

    // ignore one-char
    if (label.length <= 1) continue;

    labels.push(label);
  }

  return uniq(labels).slice(0, 10);
}

function detectOffer(snips) {
  const t = snips.join(" ").toLowerCase();
  return (
    /(\b\d{1,3}\s*%)/.test(t) ||
    /\boff\b/.test(t) ||
    /\bdiscount\b/.test(t) ||
    /\bsale\b/.test(t) ||
    /\brabatt\b/.test(t) ||
    /\brea\b/.test(t) ||
    /\berbjudande\b/.test(t) ||
    /\bkampanj\b/.test(t)
  );
}

function detectTrustSnippets(snips) {
  const patterns = [
    /trustpilot|reviews?|rating|stars?/i,
    /recension(er)?|omdömen|betyg/i,
    /loved by|trusted by|customers|users/i,
    /älskad av|betrodd av|kunder|användare/i,
    /\b\d{1,3}([.,\s]\d{3})+\s*\+?/i, // 200 000+
    /\b\d+\s*(k|m)\s*\+/i // 50k+, 2m+
  ];
  return snips.filter((s) => patterns.some((r) => r.test(s))).slice(0, 6);
}

function guessLanguage(snips) {
  const t = snips.join(" ").toLowerCase();
  const svWords = ["och", "att", "för", "med", "våra", "kontakta", "produkter", "fri frakt", "kund"];
  const hits = svWords.filter((w) => t.includes(` ${w} `) || t.startsWith(`${w} `)).length;
  return hits >= 2 ? "sv" : "en";
}

function wordCount(snips) {
  return snips.join(" ").split(/\s+/).filter(Boolean).length;
}

function detectPopups() {
  // Try to detect modals/overlays above the fold:
  // fixed/sticky + high z-index + reasonable size + non-trivial text
  const vh = window.innerHeight || 800;

  const candidates = Array.from(document.querySelectorAll("div,section,aside,dialog"))
    .filter((el) => {
      if (!visible(el)) return false;
      const r = el.getBoundingClientRect();
      if (!inViewport(r, vh)) return false;

      const s = getComputedStyle(el);
      const pos = s.position;
      if (pos !== "fixed" && pos !== "sticky") return false;

      const z = parseInt(s.zIndex || "0", 10);
      if (!Number.isFinite(z) || z < 100) return false;

      // Not tiny, not full-page background
      if (r.width < 240 || r.height < 120) return false;

      const text = (el.innerText || "").trim();
      if (text.length < 25) return false;

      return true;
    });

  const types = [];
  const joined = candidates.map((x) => (x.innerText || "").toLowerCase()).join(" ");

  if (/(subscribe|newsletter|join|sign up|nyhetsbrev|få \d+%|registrera)/.test(joined)) types.push("newsletter");
  if (/(discount|% off|rabatt|rea|offer|deal|kampanj)/.test(joined)) types.push("discount");
  if (/(cookies|gdpr|consent|integritet|cookie)/.test(joined)) types.push("cookie/consent");

  // Provide a few text snippets as evidence
  const popupSnips = uniq(candidates.map((c) => (c.innerText || "").trim().replace(/\s+/g, " "))).slice(0, 3);

  return {
    popupDetected: candidates.length > 0,
    popupTypes: types.slice(0, 3),
    popupSnippets: popupSnips
  };
}

function collectSignals() {
  const snips = getTextSnippets();
  const head = getHeadline();
  const ctas = getCTAs();
  const trust = detectTrustSnippets(snips);
  const offer = detectOffer(snips);
  const langGuess = guessLanguage(snips);

  const clickables = aboveFoldEls("button, a, [role='button'], input[type='submit']").length;
  const popup = detectPopups();

  return {
    url: location.href,
    langGuess,
    headline: head,
    primaryCtas: ctas,
    offerDetected: offer,
    trustSnippets: trust,
    popupDetected: popup.popupDetected,
    popupTypes: popup.popupTypes,
    popupSnippets: popup.popupSnippets,
    words: wordCount(snips),
    clickables,
    snippets: snips.slice(0, 35) // keep payload small
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "BRAND_MIRROR_SIGNALS") {
    try {
      sendResponse({ ok: true, signals: collectSignals() });
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
  }
  return true;
});