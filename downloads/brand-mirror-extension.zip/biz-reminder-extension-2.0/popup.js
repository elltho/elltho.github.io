const API_URL = "https://brand-mirror-api.vercel.app/api/analyze";

const scanBtn = document.getElementById("scanBtn");
const copyBtn = document.getElementById("copyBtn");
const toggleBtn = document.getElementById("toggleBtn");

const statusEl = document.getElementById("status");
const scoreEl = document.getElementById("score");
const barFillEl = document.getElementById("barFill");
const metaEl = document.getElementById("meta");

const heroEl = document.getElementById("hero");
const detailsEl = document.getElementById("details");
const traitsEl = document.getElementById("traits");
const signalsEl = document.getElementById("signals");
const evidenceEl = document.getElementById("evidence");

let latestShareLine = "";

function setStatus(t) {
  statusEl.textContent = t || "";
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function setScore(n) {
  const s = clamp(Math.round(n), 0, 100);
  scoreEl.textContent = String(s);
  barFillEl.style.width = `${s}%`;

  if (s >= 75) barFillEl.style.background = "var(--good)";
  else if (s >= 55) barFillEl.style.background = "var(--mid)";
  else barFillEl.style.background = "var(--bad)";
}

function levelFromScore(s) {
  if (s >= 75) return "good";
  if (s >= 55) return "mid";
  return "bad";
}

function escapeHtml(str) {
  return String(str || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function card({ level = "mid", headline = "", desc = "", evidence = "" }) {
  return `
    <div class="card">
      <div class="tag ${level}">${level === "good" ? "Strong" : level === "mid" ? "Improve" : "Risk"}</div>
      <div class="headline">${escapeHtml(headline)}</div>
      ${desc ? `<div class="desc">${escapeHtml(desc)}</div>` : ""}
      ${evidence ? `<div class="evidence"><b>Evidence:</b> ${escapeHtml(evidence)}</div>` : ""}
    </div>
  `;
}

function cardsFromList(list, level = "mid", empty = "—") {
  if (!list || !list.length) return `<div class="hint">${escapeHtml(empty)}</div>`;
  return list.map((t) => card({ level, headline: t })).join("");
}

function hostnameShort(url) {
  try {
    const u = new URL(url);
    return u.hostname.replace(/^www\./, "");
  } catch {
    return "—";
  }
}

function computeVibeScore(sig) {
  let score = 70;

  const headline = (sig.headline || "").trim();
  const ctas = sig.primaryCtas || [];
  const trust = sig.trustSnippets || [];
  const words = Number(sig.words || 0);
  const clickables = Number(sig.clickables || 0);

  if (!headline) score -= 12;
  else {
    if (headline.length < 12) score -= 4;
    if (headline.length > 80) score -= 6;
    score += 6;
  }

  if (ctas.length === 0) score -= 10;
  else if (ctas.length === 1) score += 6;
  else if (ctas.length === 2) score += 4;
  else score -= 4;

  if (trust.length === 0) score -= 10;
  else if (trust.length <= 2) score += 4;
  else score += 7;

  if (sig.offerDetected) score += 3;

  if (sig.popupDetected) {
    const types = sig.popupTypes || [];
    if (types.includes("cookie/consent") && types.length === 1) score -= 2;
    else score -= 10;
  }

  if (words > 220) score -= 12;
  else if (words > 160) score -= 7;
  else if (words < 35) score -= 3;
  else score += 3;

  if (clickables > 22) score -= 10;
  else if (clickables > 14) score -= 6;
  else if (clickables < 6) score += 2;

  return clamp(score, 0, 100);
}

function setDetailsOpen(open) {
  detailsEl.style.display = open ? "block" : "none";
  toggleBtn.setAttribute("aria-expanded", open ? "true" : "false");
  toggleBtn.textContent = open ? "Hide details" : "Show details";
}

toggleBtn.addEventListener("click", () => {
  const open = toggleBtn.getAttribute("aria-expanded") === "true";
  setDetailsOpen(!open);
});

copyBtn.addEventListener("click", async () => {
  if (!latestShareLine) return;
  try {
    await navigator.clipboard.writeText(latestShareLine);
    setStatus("Copied ✅");
    setTimeout(() => setStatus(""), 900);
  } catch {
    setStatus("Could not copy (clipboard blocked).");
  }
});

async function getSignalsFromPage() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab");

  const res = await chrome.tabs.sendMessage(tab.id, { type: "BRAND_MIRROR_SIGNALS" });
  if (!res?.ok) throw new Error(res?.error || "Could not read the page");

  return res.signals;
}

function clearUI() {
  heroEl.innerHTML = "";
  traitsEl.innerHTML = "";
  signalsEl.innerHTML = "";
  evidenceEl.innerHTML = "";
  latestShareLine = "";
  copyBtn.disabled = true;
}

scanBtn.addEventListener("click", async () => {
  clearUI();
  setDetailsOpen(false);
  setStatus("Collecting signals…");

  let sig;
  try {
    sig = await getSignalsFromPage();
  } catch (e) {
    setStatus("Could not read page. Reload the tab and try again.");
    return;
  }

  const vibe = computeVibeScore(sig);
  setScore(vibe);
  metaEl.textContent = `Page: ${hostnameShort(sig.url)} • Language: ${sig.langGuess || "—"}`;

  setStatus("Asking Brand Mirror…");

  try {
    const r = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ signals: sig, vibeScore: vibe, spice: "spicy" })
    });

    const data = await r.json();

    if (!data.ok) {
      setStatus("API error.");
      heroEl.innerHTML = card({
        level: "bad",
        headline: "Brand Mirror API error",
        desc: data.error || "Unknown error",
        evidence: data.detail ? String(data.detail).slice(0, 180) : ""
      });
      return;
    }

    const report = data.report;

    latestShareLine = report.share_line || "";
    copyBtn.disabled = !latestShareLine;

    const lvl = levelFromScore(vibe);

    // HERO ONLY (shareable)
    heroEl.innerHTML = card({
      level: lvl,
      headline: report.verdict,
      desc: `${report.archetype} • “${report.share_line}”`
    });

    // Details (collapsed by default)
    traitsEl.innerHTML = cardsFromList(report.traits, "good", "No traits.");
    signalsEl.innerHTML = cardsFromList(report.what_it_signals, "mid", "No signals.");
    evidenceEl.innerHTML = cardsFromList(report.evidence, "mid", "No evidence.");

    setStatus("Done ✅");

  } catch (e) {
    setStatus("Network error (API unreachable).");
    heroEl.innerHTML = card({
      level: "bad",
      headline: "Network error",
      desc: "Could not reach the API."
    });
  }
});